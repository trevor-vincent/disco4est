
#ifndef __VIEWERADIOS2IMPL_H
#define __VIEWERADIOS2IMPL_H

typedef struct {
  char          *filename;
  PetscFileMode btype;
  PetscInt      timestep;
} PetscViewer_ADIOS2;

#endif
