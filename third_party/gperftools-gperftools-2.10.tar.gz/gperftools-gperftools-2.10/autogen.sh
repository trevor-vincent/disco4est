#!/bin/sh

autoreconf -i
