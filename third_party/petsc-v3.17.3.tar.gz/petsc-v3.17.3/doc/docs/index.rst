=======================
PETSc/TAO Documentation
=======================

.. toctree::
   :maxdepth: 1

   manual/index
   manualpages/index
   changes/index

* `PETSc/TAO Users Manual in PDF <manual/manual.pdf>`__
* `Function Index <../docs/manualpages/singleindex.html>`__
